#ifndef _CONFIG_H_
#define _CONFIG_H_
#define MAIN_VERSION_MAJOR 1
#define MAIN_VERSION_MINOR 0
#define MAIN_DESCRIPTION "Eine Applikation um jsoncpp zu demonstrieren"
#endif
